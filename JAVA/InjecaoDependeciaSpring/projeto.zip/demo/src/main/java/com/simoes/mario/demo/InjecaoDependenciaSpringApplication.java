package com.simoes.mario.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class InjecaoDependenciaSpringApplication {

	public static void main(String[] args) {
		SpringApplication.run(InjecaoDependenciaSpringApplication.class, args);
	}

}
