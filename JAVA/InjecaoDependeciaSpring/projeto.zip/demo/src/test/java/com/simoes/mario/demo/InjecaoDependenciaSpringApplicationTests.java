package com.simoes.mario.demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class InjecaoDependenciaSpringApplicationTests {

	@Test
	void contextLoads() {
	}

}
