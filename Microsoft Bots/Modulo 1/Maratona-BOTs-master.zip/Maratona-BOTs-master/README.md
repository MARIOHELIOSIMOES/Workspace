![header](https://user-images.githubusercontent.com/2198735/34947967-e7469c50-f9f2-11e7-89f4-60cd1d295b39.png)

# Maratona Bots

Este é um repositório de ideias e laboratórios de apoio para os seus estudos.



| Labotório | Descrição | 
| -------- | -------- | 
| [QuickStart](https://github.com/CommunityBootcamp/Maratona-BOTs/tree/master/QuickStart)     | Configuração de ambiente de desenvolvimento em C#     | 
| [QuickStart](https://github.com/CommunityBootcamp/Maratona-BOTs/blob/master/QuickStart/configurando-ambiente-nodejs.md)     | Configuração de ambiente de desenvolvimento em Node.js    | 



# Bots Diplomado

Este es un repositorio de ideas y laboratorios de apoyo para sus estudios.

| Labotório | Descrição | 
| -------- | -------- | 
| [QuickStart](https://github.com/CommunityBootcamp/Maratona-BOTs/tree/master/QuickStartES)     | Configuración de entorno de desarrollo en C #   | 
