﻿using System.Reflection;
using System.Resources;


[assembly: AssemblyTitle("Microsoft.Bot.Connector.AspNetCore")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("Microsoft Corporation")]
[assembly: AssemblyProduct("Microsoft Bot Framework")]
[assembly: AssemblyCopyright("Copyright © Microsoft Corporation 2016")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]


[assembly: AssemblyVersion("1.1.3.2")]
[assembly: AssemblyFileVersion("1.1.3.2")]

//[assembly: AssemblyKeyFileAttribute(@"..\\..\\buildtools\\35MSSharedLib1024.snk")]
//[assembly: AssemblyDelaySignAttribute(true)]
