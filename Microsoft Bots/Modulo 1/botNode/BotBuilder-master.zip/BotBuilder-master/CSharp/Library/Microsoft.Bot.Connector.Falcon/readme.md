﻿# Falcon
This project is a special combination of .AspNetCore + .NET framework 4.61 to support Falcon/Cortana
