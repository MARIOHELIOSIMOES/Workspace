﻿using System.Reflection;
using System.Resources;

[assembly: AssemblyVersion("3.12.2.4")]
[assembly: AssemblyFileVersion("3.12.2.4")]

//[assembly: AssemblyKeyFileAttribute(@"..\\..\\buildtools\\35MSSharedLib1024.snk")] 
//[assembly: AssemblyDelaySignAttribute(true)]
