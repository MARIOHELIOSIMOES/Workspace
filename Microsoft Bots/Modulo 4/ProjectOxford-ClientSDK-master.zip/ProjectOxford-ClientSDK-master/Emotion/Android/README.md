**This project has moved to [http://www.github.com/Microsoft/Cognitive-Emotion-Android](http://www.github.com/microsoft/cognitive-emotion-android)**
==================
