**This project has moved to [http://www.github.com/Microsoft/Cognitive-Emotion-Python](http://www.github.com/microsoft/cognitive-emotion-python)**
==================
