This project has moved :house:
====================================
You can find the **full list of [Emotion SDKs and Samples on our website](https://www.microsoft.com/cognitive-services/en-us/SDK-Sample?api=emotion)**.
