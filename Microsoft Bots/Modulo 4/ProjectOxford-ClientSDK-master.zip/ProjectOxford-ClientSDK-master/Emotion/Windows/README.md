**This project has moved to [http://www.github.com/Microsoft/Cognitive-Emotion-Windows](http://www.github.com/microsoft/cognitive-emotion-windows)**
==================
