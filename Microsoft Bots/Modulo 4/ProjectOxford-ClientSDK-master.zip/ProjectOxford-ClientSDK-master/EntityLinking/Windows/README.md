**This project has moved to [http://www.github.com/Microsoft/Cognitive-EntityLinking-Windows](http://www.github.com/microsoft/cognitive-EntityLinking-Windows)**
==================
