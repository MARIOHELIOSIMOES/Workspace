**This project has moved to [http://www.github.com/Microsoft/Cognitive-Face-Android](http://www.github.com/microsoft/cognitive-Face-Android)**
==================
