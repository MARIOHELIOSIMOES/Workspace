**This project has moved to [http://www.github.com/Microsoft/Cognitive-Face-Windows](http://www.github.com/microsoft/cognitive-Face-Windows)**
==================
