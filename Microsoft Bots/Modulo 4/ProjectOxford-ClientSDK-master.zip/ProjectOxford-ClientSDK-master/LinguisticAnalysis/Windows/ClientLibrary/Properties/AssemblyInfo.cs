﻿using System.Reflection;

// General Information about an assembly is controlled through the following 
// set of attributes. Change these attribute values to modify the information
// associated with an assembly.
[assembly: AssemblyTitle("Microsoft Project Oxford Linguistics Client")]
[assembly: AssemblyDescription("Microsoft.ProjectOxford.Linguistics")]
[assembly: AssemblyCompany("Microsoft")]
[assembly: AssemblyProduct("Microsoft Project Oxford")]
[assembly: AssemblyCopyright("Copyright © 2016 Microsoft")]
[assembly: AssemblyTrademark("Microsoft")]
[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]