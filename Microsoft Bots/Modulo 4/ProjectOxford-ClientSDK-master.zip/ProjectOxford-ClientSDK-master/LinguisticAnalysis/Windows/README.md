**This project has moved to [http://www.github.com/Microsoft/Cognitive-LinguisticAnalysis-Windows](http://www.github.com/microsoft/cognitive-LinguisticAnalysis-Windows)**
==================
