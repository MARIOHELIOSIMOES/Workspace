﻿using System.Reflection;
using System.Runtime.InteropServices;

// General Information about an assembly is controlled through the following 
// set of attributes. Change these attribute values to modify the information
// associated with an assembly.
[assembly: AssemblyTitle("Microsoft.ProjectOxford.Linguistics.Sample")]
[assembly: AssemblyDescription("Microsoft.ProjectOxford.Linguistics.Sample")]
[assembly: AssemblyProduct("Microsoft Project Oxford")]
[assembly: AssemblyCopyright("Copyright © 2016 Microsoft")]
[assembly: ComVisible(false)]
[assembly: Guid("9be553c3-e1b7-4c0a-b868-02e4252fa48c")]
[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]