This project has moved :house:
====================================
We heard your feedback! This repo has been deprecated and each project has moved to a new home in a repo scoped by API and platform. We believe this is a more effective way for both you and us to make updates and get the latest SDKs & Samples.

You can now find the **full list of [SDKs and Samples on our website](https://www.microsoft.com/cognitive-services/en-us/sdk-sample).**

Happy coding!
