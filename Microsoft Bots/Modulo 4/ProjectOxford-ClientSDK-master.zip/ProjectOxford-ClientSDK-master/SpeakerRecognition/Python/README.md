**This project has moved to [http://www.github.com/Microsoft/Cognitive-SpeakerRecognition-Python](http://www.github.com/microsoft/cognitive-SpeakerRecognition-Python)**
==================
