This project has moved :house:
====================================
You can find the **full list of [Speaker Recognition SDKs and Samples on our website](https://www.microsoft.com/cognitive-services/en-us/SDK-Sample?api=speaker%20recognition)**.
