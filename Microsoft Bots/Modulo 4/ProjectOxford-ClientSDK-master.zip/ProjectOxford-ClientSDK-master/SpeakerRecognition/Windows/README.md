**This project has moved to [http://www.github.com/Microsoft/Cognitive-SpeakerRecognition-Windows](http://www.github.com/microsoft/cognitive-SpeakerRecognition-Windows)**
==================
