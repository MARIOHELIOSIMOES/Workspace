This project has moved :house:
====================================
You can find the **full list of [Bing Speech SDKs and Samples on our website](https://www.microsoft.com/cognitive-services/en-us/SDK-Sample?api=bing%20speech)**.
