**This project has moved to [http://www.github.com/Microsoft/Cognitive-Speech-STT-Javascript](http://www.github.com/microsoft/Cognitive-Speech-STT-Javascript)**
==================
