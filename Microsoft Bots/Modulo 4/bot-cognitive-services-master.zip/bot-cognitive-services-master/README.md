# Bot Cognitive Services

Código de exemplo utilizadao na Maratona de Bots da Microsoft, módulo 4 - Cognitive Services.


Acesse a maratona no link: [aka.ms/maratonabots](https://ticapacitacion.com/curso/botspt/)
